//
//  GameScene.swift
//  TicTacToe
//
//  Created by N. Mompi Devi on 29/08/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    var xos:[SKSpriteNode] = []
    var player = 0
    var cross:SKTexture?
    var nought:SKTexture?
    var marked:[Int] = [0,0,0,0,0,0,0,0,0]
    override func didMove(to view: SKView) {
        xos.append(self.childNode(withName: "1") as! SKSpriteNode)
        xos.append(self.childNode(withName: "2") as! SKSpriteNode)
        xos.append(self.childNode(withName: "3") as! SKSpriteNode)
        xos.append(self.childNode(withName: "4") as! SKSpriteNode)
        xos.append(self.childNode(withName: "5") as! SKSpriteNode)
        xos.append(self.childNode(withName: "6") as! SKSpriteNode)
        xos.append(self.childNode(withName: "7") as! SKSpriteNode)
        xos.append(self.childNode(withName: "8") as! SKSpriteNode)
        xos.append(self.childNode(withName: "9") as! SKSpriteNode)
        cross = SKTexture(imageNamed: "X")
        nought = SKTexture(imageNamed: "O")
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            for i in 0 ... xos.count-1{
                let location = touch.location(in: self)
                if(xos[i].contains(location)){
                    if(marked[i] == 0){
                        if(player == 0){
                            xos[i].texture = cross
                            player = 1
                            marked[i] = 1
                        } else {
                            xos[i].texture = nought
                            player = 0
                            marked[i] = 1
                        }
                    }
                }
            }
        }
    }
    

    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
